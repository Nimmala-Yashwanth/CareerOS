# CareerOS v3 — Start here (Mac)

This is a **separate upgraded project** built on your tested v2 FastAPI backend. It includes a **React + Vite** frontend with charts, authenticated job tracking, PDF resume parsing, explainable matching, and optional server-side LLM feedback.

## 1. Backend terminal
Open Terminal in the `careeros_pro` folder. Python 3.11 is recommended:

```bash
/opt/homebrew/bin/python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m pytest -q
uvicorn app.main:app --reload --port 8000
```

Keep this Terminal open. Backend API docs: http://127.0.0.1:8000/docs

## 2. Frontend terminal — open a NEW Terminal tab (Cmd+T)
From the `careeros_pro` folder:

```bash
cd frontend
npm install
npm run dev
```

If `npm` is not found, install Node.js LTS from https://nodejs.org or via `brew install node`.

**Open http://127.0.0.1:5173** for the NEW React dashboard.
**Port 8000** still serves the older HTML interface and API. This is intentional. Vite proxies `/api` to port 8000.

## 3. Optional real AI feedback
The basic PDF parser and keyword matching work **without any paid key**. The **Generate optional AI feedback** button calls the backend, which requires an OpenAI API key and may incur charges.

In your backend terminal, BEFORE starting uvicorn:

```bash
export OPENAI_API_KEY='your-api-key'
# optional: export OPENAI_MODEL='gpt-4o-mini'
uvicorn app.main:app --reload --port 8000
```

Never put the key in frontend files, Git, screenshots, or chats. The optional AI endpoint sends the pasted job description and detected skill lists to the external API; it does **not** send the uploaded PDF.

## 4. Existing v2 data
This ZIP does **not** include your local v2 database. If you want your old accounts/applications, stop both servers and copy your existing `careeros.db` into the new `careeros_pro` folder **only if your v2 DATABASE_URL points to that file**. Back up the old file first. Otherwise create a new account.

## 5. Test checklist
- Register/login in the React dashboard at port 5173
- Add an application, change its status, search/filter, export CSV
- See dashboard analytics and charts
- Upload a text-based PDF, compare it to a job description
- Optional: configure the API key and generate AI feedback

## Honest implementation notes
- V3 uses React + **Vite**, not Next.js. This avoids a framework migration while keeping your working FastAPI backend.
- Basic resume scoring is still **keyword requirement coverage, not an ATS score**.
- The AI feedback feature uses a real hosted model only when you supply a valid API key. No fake fallback is shown.
- Existing Python tests were carried over, but the full test suite and frontend build could not be executed in the packaging environment because dependencies were unavailable. Run the commands above locally.
- This is a substantial portfolio upgrade, **not** a production security audit or a deployed service.
