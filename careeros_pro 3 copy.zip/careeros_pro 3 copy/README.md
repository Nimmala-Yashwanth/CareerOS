# CareerOS — Full-stack job application command center

A portfolio-ready **working MVP** built with FastAPI, SQLAlchemy, PostgreSQL/SQLite, HTML/CSS/JavaScript, JWT authentication, password hashing, analytics, keyword-based job matching, CSV export, pytest, Docker Compose, GitHub Actions and Alembic.

**Important:** The matcher is explainable skill-keyword matching, **not AI/LLM** and not an ATS score. This project has no paid API requirements. Do not claim AI integration on your resume unless you implement it.

## Run locally (macOS, Python 3.11+)

```bash
cd careeros_pro
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
python -m pytest -q
uvicorn app.main:app --reload
```

Visit http://localhost:8000. Register with a new email and password of at least 10 characters. API docs: http://localhost:8000/docs. SQLite data is saved to `careeros.db` (ignored by git).

## Run with PostgreSQL + Docker

```bash
cp .env.example .env
# Edit .env and replace SECRET_KEY with a strong random value, e.g. `openssl rand -hex 32`
docker compose up --build
```

Visit http://localhost:8000. Docker Compose uses PostgreSQL 16 and runs the Alembic migration before starting the API. To stop: `docker compose down` (database retained). To delete test data: `docker compose down -v`.

## Included features

- Account registration, password hashing, login, signed JWT tokens (12-hour expiry)
- User-isolated CRUD for job applications, with status transitions
- Server-side pagination, status filtering and company/role search
- Analytics dashboard: counts, active applications, positive response percentage
- User skill profile and explainable job-description skill-gap analysis
- CSV export with spreadsheet formula-injection mitigation
- OpenAPI docs at `/docs`, health check at `/health`
- Responsive browser UI, PostgreSQL configuration, database migration, automated API tests, CI

## API examples

- `POST /api/auth/register` with `{ "email": "you@example.com", "password": "strong-password" }`
- `POST /api/auth/login` to get a bearer token
- `GET /api/applications?status=applied&limit=10&offset=0`
- `POST /api/applications`, `PATCH /api/applications/{id}`, `DELETE /api/applications/{id}`
- `GET /api/analytics`, `PUT /api/skills`, `POST /api/match`, `GET /api/export.csv`

## Testing

`python -m pytest -q` exercises registration, login, isolation, CRUD, analytics, matching and CSV safety. `python -m compileall -q app` checks syntax.

## Deploying

Deploy as a Docker web service on a platform that supports Docker and managed PostgreSQL. Set `DATABASE_URL` and a random `SECRET_KEY` in platform secrets. Run `alembic upgrade head` before starting the app and set `AUTO_CREATE_TABLES=0`. Use HTTPS. Production hardening still needed: login rate limits, refresh tokens / logout revocation, security headers, observability, backups, managed secrets, and thorough accessibility testing. The default development secret is **not safe for public deployment**.

## Suggested improvements for your next week

1. Replace the skill matcher with a real RAG/LLM pipeline and label outputs clearly.
2. Add integration tests against PostgreSQL and browser E2E tests with Playwright.
3. Add edit form, application timeline and interview reminders.
4. Deploy with a managed Postgres instance, HTTPS and logging; capture screenshots.
5. Measure query latency with a reproducible load test and document actual results.

## Resume bullet (only after you've run and verified it)

> Built a multi-user job application tracking platform with FastAPI, SQLAlchemy, JWT authentication, PostgreSQL, analytics, and a responsive dashboard; added Docker-based deployment and automated API tests via GitHub Actions.

Do not invent traffic, performance or accuracy numbers.
